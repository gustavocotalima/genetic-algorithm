Os fontes são os 2 arquivos java (em /src)
Ao executar, o programa pedirá para que os valores sejam inseridos.
Ao final, será impresso no cosole e gerado um arquivo com os dados encontrados.

O arquivo "arquivo.txt" tem os dados usados para gerar o gráfico e os resultados encontrados

grafico.m é o arquivo em matlab usado para gerar os resultados
